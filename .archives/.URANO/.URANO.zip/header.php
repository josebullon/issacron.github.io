<?php
  $title = ' URANO ';
  $tema = ' Agencia Digital ';
  $lorem1 = 'Lorem ipsum dolor sit amet. Et similique maiores aut rerum autemet voluptas et reiciendis explicabo. Quo sapiente beatae est distinctio expeditaquo quam id ipsam numquam.';
  $lorem2 = 'Lorem ipsum dolor sit amet. Et similique maiores aut rerum autemet voluptas et reiciendis explicabo.';
  $lorem3 = 'Lorem ipsum dolor sit amet? ';
  $lorem4 = 'Lorem ipsum dolor sit amet';
  $nav1 = 'Principal';
  $nav2 = 'Servicios';
  $nav3 = 'Nosotros';
  $nav4 = 'Portafolio';
  $nav5 = 'Precios';
  $nav6 = 'Galeria';
  $nav7 = 'Blog';
  $nav8 = 'Contactanos';
  $telefono = '+0 123 456 789';
  $correo = 'urano@ejemplo.com';
?>

<!DOCTYPE html>
<html lang="zxx">
  <!-- Mirrored from duruthemes.com/demo/html/nopixel/onepage-dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Sep 2023 17:32:21 GMT -->
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title><?php echo $title, $tema; ?></title>
    <!-- favicon -->
    <!-- <link rel="shortcut icon" href="img/favicon.png" /> -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <!-- css -->
    <link rel="stylesheet" href="css/plugins.css" />
    <link rel="stylesheet" href="style.css" />
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-144098545-1"></script> -->
    <!-- <script>
      window.dataLayer = window.dataLayer || [];
      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-144098545-1');
    </script> -->

    <!-- Font-Awesome CSS -->
    <link href="assets/css/all.css" rel="stylesheet" />
    <!-- Animate CSS-->
    <link href="assets/css/animate.min.css" rel="stylesheet" />
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/colors.css" />
    <!-- Live Style Switcher - demo only -->
    <link id="style-switch" href="assets/css/colors/orange.css" media="screen" rel="stylesheet" type="text/css" />

    <!--Alternate styles for demo purposes only-->
    <link href="css/switcher.css"  rel="stylesheet" type="text/css"/>
    <link href="css/styles/clr-1.css" rel="stylesheet" type="text/css" title="clr-1" media="all"/>
    <link href="css/styles/clr-2.css" rel="alternate stylesheet" type="text/css" title="clr-2" media="all" />
    <link href="css/styles/clr-3.css" rel="alternate stylesheet" type="text/css" title="clr-3" media="all" />
    <link href="css/styles/clr-4.css" rel="alternate stylesheet" type="text/css" title="clr-4" media="all" />
    <link href="css/styles/clr-5.css" rel="alternate stylesheet" type="text/css" title="clr-5" media="all" />
    <link href="css/styles/clr-6.css" rel="alternate stylesheet" type="text/css" title="clr-6" media="all" />
    <link href="css/styles/clr-7.css" rel="alternate stylesheet" type="text/css" title="clr-7" media="all" />
    <link href="css/styles/clr-8.css" rel="alternate stylesheet" type="text/css" title="clr-8" media="all" />
    <link href="css/styles/clr-9.css" rel="alternate stylesheet" type="text/css" title="clr-9" media="all" />
    <!-- <link href="css/styles/clr-10.css" rel="alternate stylesheet" type="text/css" title="clr-10" media="all" /> -->
    <!-- <link href="css/styles/clr-11.css" rel="alternate stylesheet" type="text/css" title="clr-11" media="all" /> -->
    <!-- <link href="css/styles/clr-12.css" rel="alternate stylesheet" type="text/css" title="clr-12" media="all" /> -->
    <!-- <link href="css/styles/clr-13.css" rel="alternate stylesheet" type="text/css" title="clr-13" media="all" /> -->
    <!-- <link href="css/styles/clr-14.css" rel="alternate stylesheet" type="text/css" title="clr-14" media="all" /> -->
    <!-- <link href="css/styles/clr-15.css" rel="alternate stylesheet" type="text/css" title="clr-15" media="all" /> -->
    <!-- <link href="css/styles/clr-16.css" rel="alternate stylesheet" type="text/css" title="clr-16" media="all" /> -->
    <!-- <link href="css/styles/clr-17.css" rel="alternate stylesheet" type="text/css" title="clr-17" media="all" /> -->
    <!-- <link href="css/styles/clr-18.css" rel="alternate stylesheet" type="text/css" title="clr-18" media="all" /> -->
    <!-- <link href="css/styles/clr-19.css" rel="alternate stylesheet" type="text/css" title="clr-19" media="all" /> -->
    <!-- <link href="css/styles/clr-20.css" rel="alternate stylesheet" type="text/css" title="clr-20" media="all" /> -->
    <!-- <link href="css/styles/clr-21.css" rel="alternate stylesheet" type="text/css" title="clr-21" media="all" /> -->
    <!-- <link href="css/styles/clr-22.css" rel="alternate stylesheet" type="text/css" title="clr-22" media="all" /> -->
    <!-- <link href="css/styles/clr-23.css" rel="alternate stylesheet" type="text/css" title="clr-23" media="all" /> -->
    <!-- <link href="css/styles/clr-24.css" rel="alternate stylesheet" type="text/css" title="clr-24" media="all" /> -->
    <!-- <link href="css/styles/clr-25.css" rel="alternate stylesheet" type="text/css" title="clr-25" media="all" /> -->
    <!-- <link href="css/styles/clr-26.css" rel="alternate stylesheet" type="text/css" title="clr-26" media="all" /> -->
    <!-- <link href="css/styles/clr-27.css" rel="alternate stylesheet" type="text/css" title="clr-27" media="all" /> -->
    <!-- <link href="css/styles/clr-28.css" rel="alternate stylesheet" type="text/css" title="clr-28" media="all" /> -->
    <!-- <link href="css/styles/clr-29.css" rel="alternate stylesheet" type="text/css" title="clr-29" media="all" /> -->
    <!-- <link href="css/styles/clr-30.css" rel="alternate stylesheet" type="text/css" title="clr-30" media="all" /> -->
    <!-- <link href="css/styles/clr-31.css" rel="alternate stylesheet" type="text/css" title="clr-31" media="all" /> -->
    <!-- <link href="css/styles/clr-32.css" rel="alternate stylesheet" type="text/css" title="clr-32" media="all" /> -->
    <!-- <link href="css/styles/clr-33.css" rel="alternate stylesheet" type="text/css" title="clr-33" media="all" /> -->
  </head>

  <body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
      <div id="preloader-status">
        <div class="preloader-position loader"><span></span></div>
      </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
      <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
      </svg>
    </div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <!-- Logo -->
        <a class="logo" href="index.html"> <img src="img/logo-light.png" alt="" /> </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon-bar"><i class="ti-line-double"></i></span>
        </button>
        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link active" href="index.php" data-scroll-nav="0"><?php echo $nav1; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#services" data-scroll-nav="1"><?php echo $nav2; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#about" data-scroll-nav="2"><?php echo $nav3; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#portfolio" data-scroll-nav="3"><?php echo $nav4; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#pricing" data-scroll-nav="4"><?php echo $nav5; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#gallery" data-scroll-nav="5"><?php echo $nav6; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#blog" data-scroll-nav="6"><?php echo $nav7; ?></a></li>
            <li class="nav-item"><a class="nav-link" href="index.php#contact" data-scroll-nav="7"><?php echo $nav8; ?></a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Style switcher start -->
    <div class="style-switch-wrapper">
      <div class="style-switch-button">
        <i class="fa fa-cog" aria-hidden="true"></i>
      </div>
      <h4>Color</h4>
      <ul class="color-list pl-0 mb-0">
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-1'); return false;" class="clr-1 inner" href="#"><span></span></a></li>
        <li class="outer-sm" title="2"><a onclick="setActiveStyleSheet('clr-2'); return false;" class="clr-2 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-3'); return false;" class="clr-3 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-4'); return false;" class="clr-4 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-5'); return false;" class="clr-5 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-6'); return false;" class="clr-6 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-7'); return false;" class="clr-7 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-8'); return false;" class="clr-8 inner-sm" href="#"><span></span></a></li>
        <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-9'); return false;" class="clr-9 inner-sm" href="#"><span></span></a></li>
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-10'); return false;" class="clr-10 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-11'); return false;" class="clr-11 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-12'); return false;" class="clr-12 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-13'); return false;" class="clr-13 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-14'); return false;" class="clr-14 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-15'); return false;" class="clr-15 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-16'); return false;" class="clr-16 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-17'); return false;" class="clr-17 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-18'); return false;" class="clr-18 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-19'); return false;" class="clr-19 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-20'); return false;" class="clr-20 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer"><a onclick="setActiveStyleSheet('clr-21'); return false;" class="clr-21 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-22'); return false;" class="clr-22 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-23'); return false;" class="clr-23 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-24'); return false;" class="clr-24 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-25'); return false;" class="clr-25 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer"><a onclick="setActiveStyleSheet('clr-26'); return false;" class="clr-26 inner" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-27'); return false;" class="clr-27 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-28'); return false;" class="clr-28 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-29'); return false;" class="clr-29 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-30'); return false;" class="clr-30 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-31'); return false;" class="clr-31 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-32'); return false;" class="clr-32 inner-sm" href="#"><span></span></a></li> -->
        <!-- <li class="outer-sm"><a onclick="setActiveStyleSheet('clr-33'); return false;" class="clr-33 inner-sm" href="#"><span></span></a></li> -->
      </ul>
      <h4 class="title">Cursor</h4>
      <ul class="cursor">
        <li><a class="showme show" href="#"></a></li>
        <li>
          <a class="hide" href="#">
            <svg xmlns="http://www.w3.org/2000/svg" class="svg" id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512">
              <g>
                <path d="m451.002 183.574h29.997v84.853h-29.997z" transform="matrix(.707 -.707 .707 .707 -23.318 395.706)"></path>
                <path d="m271.002 3.574h29.997v84.853h-29.997z" transform="matrix(.707 -.707 .707 .707 51.241 215.706)"></path>
                <path d="m423.574 31.002h84.853v29.997h-84.853z" transform="matrix(.707 -.707 .707 .707 103.961 342.985)"></path>
                <path d="m42.422 512 150.458-150.458 42.114 125.464 152.988-362.988-362.988 152.988 125.464 42.114-150.458 150.458z"></path>
                <path d="m361 0h30v61h-30z"></path>
                <path d="m451 121h61v30h-61z"></path>
              </g>
            </svg>
          </a>
        </li>
      </ul>
    </div>
    <!-- Style switcher End -->
